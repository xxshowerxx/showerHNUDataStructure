#include<bits/stdc++.h>
#include"List.h"
using namespace std;
int main() {
    List pn,pm;
    pn.input();
    pm.input();
    List ans(pn+pm);
    ans.print();
    return 0;
}
